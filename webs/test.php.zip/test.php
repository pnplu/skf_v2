<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Count Character</title>
  </head>
  <body>
    <p>Click the button to return the number of characters in the string.</p>

<script>
function myFunction() {
    // var str = "Hello World!sdfsdfsdnfisdifn";
    var n = str.length;
    document.getElementById("demo").innerHTML = n;
}
</script>

<textarea name="name" rows="8" cols="80" onKeyUp="document.getElementById('text2').value=this.value.length">
</textarea>
<!-- <p id="text2">sdf</p> -->
<input id='text2' type="text" readonly="">
  </body>
</html>
